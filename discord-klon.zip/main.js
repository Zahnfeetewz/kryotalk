const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { JsonDB } = require('./src/db');
const auth = require('./src/auth');
const rarity = require('./src/rarity');

let mainWindow;
let db;
let uploadsDir;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 800,
    minHeight: 560,
    backgroundColor: '#1e1f22',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'login.html'));
}

app.whenReady().then(() => {
  const userDataPath = app.getPath('userData');
  uploadsDir = path.join(userDataPath, 'uploads');
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

  db = new JsonDB(path.join(userDataPath, 'db.json'));

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---- IPC: Auth ----

ipcMain.handle('auth:register', async (event, { username, password }) => {
  return auth.register(db, { username, password });
});

ipcMain.handle('auth:login', async (event, { username, password }) => {
  return auth.login(db, { username, password });
});

ipcMain.handle('auth:checkUsername', async (event, { username }) => {
  const format = rarity.validateUsernameFormat(username);
  if (!format.ok) return { ok: false, error: format.reason };
  const taken = !!db.getUserByUsername(username);
  const tier = rarity.getRarityForLength(username.length);
  const availability = rarity.checkAvailability(username, db.getAllUsernames());
  return {
    ok: true,
    taken,
    rarityKey: tier.key,
    rarityLabel: tier.label,
    remaining: availability.remaining,
  };
});

// ---- IPC: Profil (Avatar/Banner/Theme) ----

ipcMain.handle('profile:pickImage', async (event, { kind }) => {
  // kind: 'avatar' | 'banner'
  const filters = kind === 'banner'
    ? [{ name: 'Bilder & GIFs', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }]
    : [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'webp'] }];

  const result = await dialog.showOpenDialog(mainWindow, {
    title: kind === 'banner' ? 'Banner auswählen' : 'Avatar auswählen',
    properties: ['openFile'],
    filters,
  });

  if (result.canceled || result.filePaths.length === 0) {
    return { ok: false, canceled: true };
  }

  const srcPath = result.filePaths[0];
  const ext = path.extname(srcPath).toLowerCase();
  const destName = `${kind}_${Date.now()}${ext}`;
  const destPath = path.join(uploadsDir, destName);
  fs.copyFileSync(srcPath, destPath);

  return {
    ok: true,
    path: destPath,
    isGif: ext === '.gif',
  };
});

// App-Hintergrund: Bild, GIF oder Video (mp4/webm). Analog zur BackgroundLayer
// aus PARALLAX (app.py) — Datei wird kopiert, Art wird per Endung erkannt.
ipcMain.handle('profile:pickBackground', async (event) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'App-Hintergrund auswählen',
    properties: ['openFile'],
    filters: [
      { name: 'Bilder, GIFs & Videos', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'mp4', 'webm'] },
    ],
  });

  if (result.canceled || result.filePaths.length === 0) {
    return { ok: false, canceled: true };
  }

  const srcPath = result.filePaths[0];
  const ext = path.extname(srcPath).toLowerCase();
  const destName = `background_${Date.now()}${ext}`;
  const destPath = path.join(uploadsDir, destName);
  fs.copyFileSync(srcPath, destPath);

  let kind = 'image';
  if (ext === '.gif') kind = 'gif';
  else if (ext === '.mp4' || ext === '.webm') kind = 'video';

  return { ok: true, path: destPath, kind };
});

ipcMain.handle('profile:update', async (event, { userId, patch }) => {
  const updated = db.updateUser(userId, patch);
  if (!updated) return { ok: false, error: 'Nutzer nicht gefunden.' };
  return { ok: true, user: auth.publicUser(updated) };
});

ipcMain.handle('profile:get', async (event, { userId }) => {
  const user = db.getUserById(userId);
  if (!user) return { ok: false, error: 'Nutzer nicht gefunden.' };
  return { ok: true, user: auth.publicUser(user) };
});
