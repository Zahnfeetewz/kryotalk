const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  register: (username, password) => ipcRenderer.invoke('auth:register', { username, password }),
  login: (username, password) => ipcRenderer.invoke('auth:login', { username, password }),
  checkUsername: (username) => ipcRenderer.invoke('auth:checkUsername', { username }),

  pickImage: (kind) => ipcRenderer.invoke('profile:pickImage', { kind }),
  pickBackground: () => ipcRenderer.invoke('profile:pickBackground'),
  updateProfile: (userId, patch) => ipcRenderer.invoke('profile:update', { userId, patch }),
  getProfile: (userId) => ipcRenderer.invoke('profile:get', { userId }),
});
