const userId = localStorage.getItem('currentUserId');
if (!userId) {
  window.location.href = 'login.html';
}

let currentUser = null;
let currentChannel = 'allgemein';

function toFileUrl(p) {
  if (!p) return '';
  return 'file://' + p.replace(/\\/g, '/');
}

function defaultAvatarDataUrl(letter) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64">
    <rect width="64" height="64" fill="#5865f2"/>
    <text x="32" y="40" font-size="24" fill="#fff" text-anchor="middle" font-family="sans-serif">${letter}</text>
  </svg>`;
  return 'data:image/svg+xml;base64,' + btoa(svg);
}

async function loadProfile() {
  const result = await window.api.getProfile(userId);
  if (!result.ok) {
    window.location.href = 'login.html';
    return;
  }
  currentUser = result.user;
  applyProfileToUI();
}

function applyProfileToUI() {
  document.body.dataset.theme = currentUser.theme || 'dark';

  const avatarUrl = currentUser.avatarPath
    ? toFileUrl(currentUser.avatarPath)
    : defaultAvatarDataUrl(currentUser.username[0].toUpperCase());

  document.getElementById('user-avatar').src = avatarUrl;
  document.getElementById('user-name').textContent = currentUser.username;
  document.getElementById('user-rarity').textContent = currentUser.rarityLabel;

  document.querySelectorAll('.theme-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.theme === currentUser.theme);
  });

  // Profilkarte im Profil-Modal
  document.getElementById('profile-avatar').src = avatarUrl;
  document.getElementById('profile-username').textContent = currentUser.username;

  const rarityTag = document.getElementById('profile-rarity-tag');
  rarityTag.textContent = currentUser.rarityLabel;
  rarityTag.className = `rarity-tag rarity-${currentUser.rarityKey}`;

  const banner = document.getElementById('profile-banner');
  banner.style.backgroundImage = currentUser.bannerPath
    ? `url("${toFileUrl(currentUser.bannerPath)}")`
    : 'none';

  const aboutMe = document.getElementById('about-me');
  if (document.activeElement !== aboutMe) {
    aboutMe.value = currentUser.aboutMe || '';
  }

  const created = new Date(currentUser.createdAt);
  document.getElementById('profile-created').textContent = created.toLocaleDateString('de-DE', {
    day: '2-digit', month: 'long', year: 'numeric',
  });

  applyBackground();
}

function applyBackground() {
  const bgContainer = document.getElementById('app-background');
  const bgImage = document.getElementById('bg-image');
  const bgVideo = document.getElementById('bg-video');
  const soundRow = document.getElementById('bg-sound-row');

  bgImage.classList.remove('showing');
  bgVideo.classList.remove('showing');
  bgVideo.pause();
  soundRow.classList.add('hidden');

  if (!currentUser.backgroundPath) {
    bgContainer.classList.remove('active');
    document.body.classList.remove('has-bg');
    return;
  }

  document.body.classList.add('has-bg');
  bgContainer.classList.add('active');

  if (currentUser.backgroundKind === 'video') {
    bgVideo.src = toFileUrl(currentUser.backgroundPath);
    bgVideo.muted = !currentUser.backgroundSound;
    bgVideo.classList.add('showing');
    bgVideo.play().catch(() => {});
    soundRow.classList.remove('hidden');
    document.getElementById('bg-sound-toggle').checked = !!currentUser.backgroundSound;
  } else {
    bgImage.src = toFileUrl(currentUser.backgroundPath);
    bgImage.classList.add('showing');
  }
}

// ---- Channels (lokal, ohne Server) ----
function messagesKey(channel) {
  return `messages:${userId}:${channel}`;
}

function renderMessages(channel) {
  const list = document.getElementById('messages');
  list.innerHTML = '';
  const stored = JSON.parse(localStorage.getItem(messagesKey(channel)) || '[]');
  stored.forEach((m) => appendMessageToDom(m));
  list.scrollTop = list.scrollHeight;
}

function appendMessageToDom(m) {
  const list = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'msg';
  const time = new Date(m.time).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  div.innerHTML = `<span class="author">${m.author}</span>${m.text}<span class="time">${time}</span>`;
  list.appendChild(div);
  list.scrollTop = list.scrollHeight;
}

document.querySelectorAll('.channel').forEach((el) => {
  el.addEventListener('click', () => {
    document.querySelectorAll('.channel').forEach((c) => c.classList.remove('active'));
    el.classList.add('active');
    currentChannel = el.dataset.channel;
    document.getElementById('current-channel').textContent = `# ${currentChannel}`;
    renderMessages(currentChannel);
  });
});

document.getElementById('message-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const input = document.getElementById('message-input');
  const text = input.value.trim();
  if (!text) return;
  const msg = { author: currentUser.username, text, time: Date.now() };
  const key = messagesKey(currentChannel);
  const stored = JSON.parse(localStorage.getItem(key) || '[]');
  stored.push(msg);
  localStorage.setItem(key, JSON.stringify(stored));
  appendMessageToDom(msg);
  input.value = '';
});

// ---- Einstellungen ----
const overlay = document.getElementById('settings-overlay');

document.getElementById('open-settings').addEventListener('click', () => {
  overlay.classList.remove('hidden');
});

document.getElementById('close-settings').addEventListener('click', () => {
  overlay.classList.add('hidden');
});

document.getElementById('pick-avatar').addEventListener('click', async () => {
  const result = await window.api.pickImage('avatar');
  if (!result.ok) return;
  const patch = { avatarPath: result.path };
  const updated = await window.api.updateProfile(userId, patch);
  if (updated.ok) {
    currentUser = updated.user;
    applyProfileToUI();
  }
});

document.getElementById('pick-banner').addEventListener('click', async () => {
  const result = await window.api.pickImage('banner');
  if (!result.ok) return;
  const patch = { bannerPath: result.path, bannerType: result.isGif ? 'gif' : 'image' };
  const updated = await window.api.updateProfile(userId, patch);
  if (updated.ok) {
    currentUser = updated.user;
    applyProfileToUI();
  }
});

let aboutMeTimer = null;
document.getElementById('about-me').addEventListener('input', (e) => {
  clearTimeout(aboutMeTimer);
  const value = e.target.value;
  aboutMeTimer = setTimeout(async () => {
    const updated = await window.api.updateProfile(userId, { aboutMe: value });
    if (updated.ok) currentUser = updated.user;
  }, 500);
});

document.getElementById('pick-background').addEventListener('click', async () => {
  const result = await window.api.pickBackground();
  if (!result.ok) return;
  const patch = {
    backgroundPath: result.path,
    backgroundKind: result.kind,
    backgroundSound: false,
  };
  const updated = await window.api.updateProfile(userId, patch);
  if (updated.ok) {
    currentUser = updated.user;
    applyBackground();
  }
});

document.getElementById('clear-background').addEventListener('click', async () => {
  const updated = await window.api.updateProfile(userId, {
    backgroundPath: null,
    backgroundKind: null,
    backgroundSound: false,
  });
  if (updated.ok) {
    currentUser = updated.user;
    applyBackground();
  }
});

document.getElementById('bg-sound-toggle').addEventListener('change', async (e) => {
  const updated = await window.api.updateProfile(userId, { backgroundSound: e.target.checked });
  if (updated.ok) {
    currentUser = updated.user;
    document.getElementById('bg-video').muted = !currentUser.backgroundSound;
  }
});

document.querySelectorAll('.theme-btn').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const theme = btn.dataset.theme;
    const updated = await window.api.updateProfile(userId, { theme });
    if (updated.ok) {
      currentUser = updated.user;
      applyProfileToUI();
    }
  });
});

loadProfile().then(() => renderMessages(currentChannel));
