const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const formTitle = document.getElementById('form-title');

tabLogin.addEventListener('click', () => {
  tabLogin.classList.add('active');
  tabRegister.classList.remove('active');
  loginForm.classList.remove('hidden');
  registerForm.classList.add('hidden');
  formTitle.textContent = 'Willkommen zurück';
});

tabRegister.addEventListener('click', () => {
  tabRegister.classList.add('active');
  tabLogin.classList.remove('active');
  registerForm.classList.remove('hidden');
  loginForm.classList.add('hidden');
  formTitle.textContent = 'Konto erstellen';
});

// ---- Login ----
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  errorEl.textContent = '';

  const result = await window.api.login(username, password);
  if (!result.ok) {
    errorEl.textContent = result.error;
    return;
  }
  localStorage.setItem('currentUserId', result.user.id);
  window.location.href = 'app.html';
});

// ---- Registrierung: Live-Rarity-Anzeige ----
const regUsername = document.getElementById('reg-username');
const usernameHint = document.getElementById('username-hint');
let checkTimer = null;

regUsername.addEventListener('input', () => {
  clearTimeout(checkTimer);
  const value = regUsername.value.trim();
  if (!value) {
    usernameHint.innerHTML = '';
    return;
  }
  checkTimer = setTimeout(async () => {
    const result = await window.api.checkUsername(value);
    if (!result.ok) {
      usernameHint.innerHTML = `<span style="color:#fa777c">${result.error}</span>`;
      return;
    }
    const badge = `<span class="rarity-badge rarity-${result.rarityKey}">${result.rarityLabel}</span>`;
    if (result.taken) {
      usernameHint.innerHTML = `Bereits vergeben ${badge}`;
    } else {
      usernameHint.innerHTML = `Verfügbar ${badge} · noch ${result.remaining.toLocaleString('de-DE')} Namen dieser Länge frei`;
    }
  }, 250);
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = regUsername.value.trim();
  const password = document.getElementById('reg-password').value;
  const password2 = document.getElementById('reg-password2').value;
  const errorEl = document.getElementById('register-error');
  errorEl.textContent = '';

  if (password !== password2) {
    errorEl.textContent = 'Passwörter stimmen nicht überein.';
    return;
  }

  const result = await window.api.register(username, password);
  if (!result.ok) {
    errorEl.textContent = result.error;
    return;
  }
  localStorage.setItem('currentUserId', result.user.id);
  window.location.href = 'app.html';
});
