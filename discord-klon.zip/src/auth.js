const bcrypt = require('bcryptjs');
const { randomUUID } = require('crypto');
const rarity = require('./rarity');

function register(db, { username, password, avatarPath, bannerPath, bannerType }) {
  const format = rarity.validateUsernameFormat(username);
  if (!format.ok) {
    return { ok: false, error: format.reason };
  }

  if (!password || password.length < 1) {
    return { ok: false, error: 'Passwort darf nicht leer sein.' };
  }

  if (db.getUserByUsername(username)) {
    return { ok: false, error: 'Dieser Benutzername ist bereits vergeben.' };
  }

  const existingUsernames = db.getAllUsernames();
  const availability = rarity.checkAvailability(username, existingUsernames);
  if (availability.remaining <= 0) {
    return { ok: false, error: 'Für diese Namenslänge sind keine Kombinationen mehr frei.' };
  }

  const tier = rarity.getRarityForLength(username.length);
  const passwordHash = bcrypt.hashSync(password, 10);

  const user = {
    id: randomUUID(),
    username,
    passwordHash,
    avatarPath: avatarPath || null,
    bannerPath: bannerPath || null,
    bannerType: bannerType || 'image', // 'image' oder 'gif'
    theme: 'dark',
    accentColor: '#5865F2',
    rarityKey: tier.key,
    rarityLabel: tier.label,
    aboutMe: '',
    backgroundPath: null,
    backgroundKind: null,
    backgroundSound: false,
    createdAt: new Date().toISOString(),
  };

  db.createUser(user);
  return { ok: true, user: publicUser(user) };
}

function login(db, { username, password }) {
  const user = db.getUserByUsername(username);
  if (!user) {
    return { ok: false, error: 'Benutzername oder Passwort ist falsch.' };
  }
  const valid = bcrypt.compareSync(password, user.passwordHash);
  if (!valid) {
    return { ok: false, error: 'Benutzername oder Passwort ist falsch.' };
  }
  return { ok: true, user: publicUser(user) };
}

function publicUser(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}

module.exports = { register, login, publicUser };
