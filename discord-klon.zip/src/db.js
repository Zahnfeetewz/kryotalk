const fs = require('fs');
const path = require('path');

class JsonDB {
  constructor(dbFilePath) {
    this.dbFilePath = dbFilePath;
    this._ensureFile();
  }

  _ensureFile() {
    const dir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(this.dbFilePath)) {
      fs.writeFileSync(this.dbFilePath, JSON.stringify({ users: [] }, null, 2));
    }
  }

  _read() {
    const raw = fs.readFileSync(this.dbFilePath, 'utf-8');
    try {
      return JSON.parse(raw);
    } catch (e) {
      return { users: [] };
    }
  }

  _write(data) {
    fs.writeFileSync(this.dbFilePath, JSON.stringify(data, null, 2));
  }

  getAllUsers() {
    return this._read().users;
  }

  getAllUsernames() {
    return this.getAllUsers().map((u) => u.username);
  }

  getUserByUsername(username) {
    const lower = username.toLowerCase();
    return this.getAllUsers().find((u) => u.username.toLowerCase() === lower) || null;
  }

  getUserById(id) {
    return this.getAllUsers().find((u) => u.id === id) || null;
  }

  createUser(user) {
    const data = this._read();
    data.users.push(user);
    this._write(data);
    return user;
  }

  updateUser(id, patch) {
    const data = this._read();
    const idx = data.users.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    data.users[idx] = { ...data.users[idx], ...patch };
    this._write(data);
    return data.users[idx];
  }
}

module.exports = { JsonDB };
